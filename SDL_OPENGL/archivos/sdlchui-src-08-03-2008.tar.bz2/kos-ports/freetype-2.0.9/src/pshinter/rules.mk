#
# FreeType 2 PSHinter driver configuration rules
#


# Copyright 2001 by
# David Turner, Robert Wilhelm, and Werner Lemberg.
#
# This file is part of the FreeType project, and may only be used, modified,
# and distributed under the terms of the FreeType project license,
# LICENSE.TXT.  By continuing to use, modify, or distribute this file you
# indicate that you have read the license and understand and accept it
# fully.


# PSHINTER driver directory
#
PSHINTER_DIR  := $(SRC_)pshinter
PSHINTER_DIR_ := $(PSHINTER_DIR)$(SEP)


# compilation flags for the driver
#
PSHINTER_COMPILE := $(FT_COMPILE) $I$(PSHINTER_DIR)


# PSHINTER driver sources (i.e., C files)
#
PSHINTER_DRV_SRC := $(PSHINTER_DIR_)pshrec.c   \
                    $(PSHINTER_DIR_)pshglob.c  \
                    $(PSHINTER_DIR_)pshmod.c   \
                    $(PSHINTER_DIR_)pshalgo1.c \
                    $(PSHINTER_DIR_)pshalgo2.c


# PSHINTER driver headers
#
PSHINTER_DRV_H := $(PSHINTER_DRV_SRC:%c=%h)


# PSHINTER driver object(s)
#
#   PSHINTER_DRV_OBJ_M is used during `multi' builds.
#   PSHINTER_DRV_OBJ_S is used during `single' builds.
#
PSHINTER_DRV_OBJ_M := $(PSHINTER_DRV_SRC:$(PSHINTER_DIR_)%.c=$(OBJ_)%.$O)
PSHINTER_DRV_OBJ_S := $(OBJ_)pshinter.$O

# PSHINTER driver source file for single build
#
PSHINTER_DRV_SRC_S := $(PSHINTER_DIR_)pshinter.c


# PSHINTER driver - single object
#
$(PSHINTER_DRV_OBJ_S): $(PSHINTER_DRV_SRC_S) $(PSHINTER_DRV_SRC) \
                       $(FREETYPE_H) $(PSHINTER_DRV_H)
	$(PSHINTER_COMPILE) $T$@ $(PSHINTER_DRV_SRC_S)


# PSHINTER driver - multiple objects
#
$(OBJ_)%.$O: $(PSHINTER_DIR_)%.c $(FREETYPE_H) $(PSHINTER_DRV_H)
	$(PSHINTER_COMPILE) $T$@ $<


# update main driver object lists
#
DRV_OBJS_S += $(PSHINTER_DRV_OBJ_S)
DRV_OBJS_M += $(PSHINTER_DRV_OBJ_M)


# EOF

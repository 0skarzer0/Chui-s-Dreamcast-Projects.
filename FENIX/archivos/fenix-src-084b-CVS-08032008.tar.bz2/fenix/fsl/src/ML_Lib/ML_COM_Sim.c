/*---------------------------------------------------------------------------

	                  GNU Lesser General Public License

------------------------------------------------------------------------------
    Markup Languaje Library ML_Lib version 0.1
    Copyright (C) 2004  Diego Blazquez Garcia, alias (Mortimor)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

------------------------------------------------------------------------------*/

#include "ML_COM_Sim.h"

/******************************************************************************
		Aqui comienza la interfaz IUnknown para objetos del tipo nodo
*******************************************************************************/

/*Funciones COM*/
void unknown_AddRef (IUnknown this)
{
	this->p_this->AddRef(this->p_this);
}

void unknown_Release (IUnknown this)
{
	this->p_this->Release(this->p_this);;
	 
	free (this);
}

int unknown_QueryInterface (IUnknown this, int IID, void **p_IObj)
{
	return this->p_this->QueryInterface(this->p_this,IID,p_IObj);
}

/*Funcion de inicializacion de las interfaces IUnknown*/
void unknown_init (IUnknown interfaz, p_com_obj objeto)
{
	interfaz->p_this = objeto;
	objeto->AddRef(objeto);
	interfaz->AddRef = unknown_AddRef;
	interfaz->Release = unknown_Release;
	interfaz->QueryInterface = unknown_QueryInterface;
}

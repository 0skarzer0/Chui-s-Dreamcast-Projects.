                                                                                  
 _____       .____            ____. .________                                     
 NF"4NNN   .NNN"4NN         .NNF"NN `"""NF"""                                    
 N)   `NL  NN`    ` (NNNNL  (N.         N)    NNNNN. (N) .N) (N) NNNNN. (N)  (N)
 N)    4N  NF       `"  4N) (NNNN_.     N)    "` `NN `N) JNN (N` "` `NN  NN  NN
 N)    JN  NL       JNNNNN)   "4NNN)    N)   .NNNNNN  NN.N"N)NN .NNNNNN  (N)(N)
 N)   .NF  NN.    . NF   N) .     N)    N)   (N`  (N  (NJF 4NN) (N`  (N   4NNF 
 NL_JNNN   `NNN_JNN NNLJNN) (NN_JNN`    N)   (NN_NNN   NN` `NN  (NN_NNN   `NN`  
 """""       `""""   """ "`  `""""      "`    `""``"   ""   ""   `""``"   (N)  
                                                                         .NN      

GPL/GNU Open Source Atari ST Emulator for Dreamcast

http://chui.dcemu.co.uk/dcastaway.shtml




	********************
	* TERMS OF LICENSE *
	********************

This Emulator is free software; you can redistribute it and/or modify it under
 the terms of the GNU General Public License as published by the Free Software 
Foundation; either version 2 of the License, or (at your option) any later version.
To view the licence online, go to: http://www.gnu.org/copyleft/gpl.html 



	********************
	* What's DCaSTaway *
	********************

The First AtariST Emulator for Sega Dreamcast. 

In september 2004 Chui & Ron decided to port an Atari ST Emulator: 

We're finding emulators for other environments, with two conditions:

The portability and a very important thing the Simple DirectMedia Layer. (SDL)

Two emulators were found , Castaway and Hatari. (sourceforge.net)

HATARI----> http://hatari.sourceforge.net
CASTAWAY -> http://castaway.sourceforge.net

The Castaway project includes an MC68000(tm) emulator and an Atari ST (tm) emulator. 
The user interface is based on the SDL library, thus the ST emulator is adaptable to 
many platforms.

Hatari is an Atari ST emulator for Linux, BSD, BeOS, Mac OS X and other systems that 
are supported by the SDL library.

Well, based originally in both emulators all code parts were re-written and optimized 
for Dreamcast, and DCaSTaway is the result of the effort done to bring to DC this 
excellent Atari ST emulator in 3 flavours, DC, Win and Linux.

Currently DCaSTaway emulator is candidate release to final: 


- Supports MSA & ST disks images.
- Mouse & Keyboard Dreamcast supported.
- Mouse is emulated with analog pad + Y,B buttons.
- AutoFrameskip ( if needed) for real speed.
- Fast and accurated (FAME) Motorola 68000 emulation.
- Joystick is emulated with digital pad + A,X buttons.
- Virtual Keyboard with triggers L-R.
- X button Map a ST-key using X button under Virtual Keyboard.
- ZIP support.
- Filemanager with subdirectories access.
- Complete menu with 'start' button: load, frameskip, reset...
- Crystalline Sound.
- 2 joysticks emulated.
- Under PAL dreamcasts ask 60-50Hz selection.
- 100 % speed and 100 % compatibility.
- TV Filter using OpenGL (not for Dreamcast).

For running this emulator, you must have a file image of atari BIOS (TOS) named 
'ROM' at root cd-rom.

New features have been added to this release candiadate 6 prior to Final Version : 

- Savestates

There's a SubMenu called "SAVESTATE", in where you can find 4 slots to Save and
Load from memory, if you reset the emulator that savestates are losted.
Even using compressioin you will need a memory card with more than 1 MBit, 
compressed using Zip-9 takes a lot of memory at the moment.

- MKCache

DCaSTaway File Manager now try to know which games are in every disk image, 
it's possible quering a CRC database that contains the most typical Atari ST 
disk images (automation menues, medway boys, etc...

The CRC calculation can take a while during the loading
To solve this delay, the best you can do is to create a file from Linux, Windows or MacOSX with the mkcache.exe that its included into DCaStaway.

You only need to copy the EXE file mkcache.exe to the folder or directory in 
where all your ATARI ST images are, .zip, .st . msd. Running the EXE will 
generate a file called stcache.txt

If DCaSTaway file manager detects this stcache.txt file, will be interpreted 
and will not calculate the CRC included in that cache, reducing dramatically 
the files sample time.

The FAQ will be opened for public questions, and you always can use 
the dcemu.co.uk DCaSTaway Forums.


	********************************
	* GUIDE to OPERATION DCASTAWAY *
	********************************

In first place, this guide is for all. Those that you got coders-cable and BBA already 
knows of the simple thing which it is, but many of you, will feel an insatiable desire 
to put into work and to discover what the emue is able to do, therefore the steps to 
make it work are the following ones:

1) You will need a TOS and an empty image disc of the ST.
The TOS is the ROM of ATARI ST, this same when having copyright must be obtained from 
the ATARI ST that tengais in house or unloading EMUTOS, that is a totally compatible 
ROM with the TOS and is OPENSOURCE.

http://emutos.sourceforge.net

The disc image you can download from Internet, you cam use a searcher to find using a 
common finder.

2) You can download the DCaSTaway binary from DOWNLOADS Section


3) Once we have the necessary files that they are:

TOS
ST DISC IMAGE (MSA, ZIP, IMG, DSK)
DCaSTaway BIN (Binary of DC - 1st_read.bin)
We placed in a directory and proceed to name them

TOS or EMUTOS must be renamed themselves like ROM
The ST disc image will happen to be called DISKB
and finally the binary one of DC that is called 1ST_READ.BIN

4) If you got games of ST in format IMG or ST simply put into the same folder that 
the 3 previous files.

5) We burn that folder in the cdrom's root, 

Once our CDROM is burned, we already can come to execute DCaSTaway.

################################################
# - IN ORDER TO MAKE RUN THE EMU OF ATARI ST.  #
################################################

Two possibilities exist, or with UTOPIA BOOT DISK or the one that I recommend to all
so that the results are optimal.

We introduce the disc of utopia and to continuation the one that we have burned and 
VOILA! to run
The other the most recommended option and is to use APPS of DC as they are DCHACKER 
or DEMO MENU. Other way is to use Self Boot Inducer.

We come to load DCHACKER (he is available in www.dcevolution.com and he is autoboot 
(also will be used for a lot of more programs and things to you) 

DCaSTaway supports 1024 files per Directory . Max Recommended, 128 files Max per directory, 
it gives speed up loading.

The X button can be mapped as any ST Keyboard key by default is mapped as joystick up


- Windows, GNU/Linux and MacOS/X versions.

Originally only for testing.
Joystick is emulated as cursor keys and Ctrl for fire button.
F11: Enter menu.
F12: Toggle fullscreen.



- ROM 

1: Use dcastaway with TOS 1.04UK. (any Tos ROM should be ok now)

2: You must include it (named 'ROM' without extension) in the root directory of the disk for Dreamcast and copy the TOS (named 'ROM') in same EXE directory for others targets.

3: Dcastaway have a filemanager.

4: Put your ST images where you want, filemanager have subdirs navigate. You see 'cannot find rom image' message because dont can find 'ROM' file in the root directory.




	**********************
	* COMPATIBILITY LIST *
	**********************


After a testing and Beta period, we're working hard to fix all possible


The First AtariST Emulator for Sega Dreamcast.


Here are some games we have tested on DCaSTaway

BLOCKOUT 
PUB
SIMCITY 
SEGA OUTRUN 
eartic moves 
history  
barbarian  
Lotus Spirit  
stunt car racer   
commando
1942 
Elite
Frontier
Maniac Mansion:
Kick Off 
Another World 
Sensible Soccer
Dyna Blaster 
Great Gianna Sisters
Golden Axe
Sensible World Of Soccer 
Lemmings  
Another World 
Ghosts and goblins  
karate kid 2 
speedball 
Fire and forget
strider
goldrunner
Ninja mission
Buggyboy 
Fernandez must die 
IK+ 
Championship wrestling 
BLOCKOUT 
PUB 
SIMCITY 
eartic moves 
history  
barbarian  
Lotus Spirit  
stunt car racer 
commando  
1942  
Another World 
Sensible Soccer
Dyna Blaster 
Golden Axe
Sensible World Of Soccer 
Lemmings
Another World Shadow Of The Beast 
Toki 
Chase HQ 
Chase HQ2 
action fighter
Voyager 
Advance Destroyer Simulator 
Albedo 
Altered Beast 
Anarchy  
Aquanaut 
Armada
Atomic Robo Kid 
Bionic Commandos 
Blood Money 
Bubble Trouble 
Bard's Tale 
Captain Blood 
Cartoon Capers 
Stryx 
Cybernoid 2 
Crackdown
Double Dragon 
Double Dragon 2 
Darius + 
E-Swat 
Fire & Forget 
Ghouls 'N Ghosts 
Hackers II 
Flinstone 
Impact 
Night Shift -
Jack Nicklaus Golf 
James Pond 
Phobia 
Jaws 
Karateka 
Zany Golf 
Killing Game Show
KlaXX 
Licence To Kill 
Loom 
Luxor
MAD Show 
Murder in space
1stWord 
Alien Storm
Another World 
Bionic Commando 
Captain Fizz 
Castle Master 
Cybernoid 
Disk Doctor 
Elf 
G-Lock 
Ghouls and Ghosts 
Hillsfar 
Lotus III 
Marble Madness 
Mr. Heli 
R-Type II 
Side Arms 
Silent Service 
Space Harrier 
Strider II 
Turbo Outrun 
Virus 
Wargame Construction Set 
Xenakis 
Xor
1stWord 
Another World 
Bionic Commando 
Captain Fizz 
Castle Master 
Cybernoid 
Disk Doctor
Dragon Ninja 
Elf 
G-Lock 
Ghouls and Ghosts 
Hillsfar 
Lotus III 
Marble Madness 
Mr. Heli 
R-Type II 
Side Arms 
Silent Service 
Space Harrier 
Strider II 
Turbo Outrun 
Virus 
Wargame Construction Set 
Xenakis 
Xor 
speedball 
stuntcar racer 
turrican 2  
Swiv 
buggyboy 
z-out 
chaos engine 
rtype2 
jimmy whites snooker 
xor 
Annals of rome 
saint and greaves 
supersprint 
lotus III
silent service II
table tennis
kickoff II 
mercenary
maniax 
push over 2  
road wars 
red storm 
overlander 
prohibition 
oids  
knightmare 
olympiad
karate kid 
moon patrol 
paradroid
super off road 
simulcra perfect
realms 
rainbow islands 
vroom 
first samurai 
gods 
silkworm 
volfied 
venus the flytrap 
little computer people (house on a disk) 
sabre team
alpha waves
parasol stars 
exile
Waterloo
Cybercon III 
Armourgedden  
empire strikes bacdk
into the eagles nest
trantor the stormtrooper
plutos 
knightmare 
arcade classics
starquake
better dead than alien
super hang on 
st karate 
electronic pool 
elite 
screaming wings 
mouse trap 
the enforcer
battlezone 
slap fight 
chuckie egg 
menace 
zany golf 
mission 
starglider
voyager
marble madness 
head over heels
harely davidson 
arcade trivia quiz 
toki 
supercars II 
chips challenge
ranarama
do run run
chase hq
kick off 
chuckie egg II 
laser squad 
st dragon 
paradroid 
pub trivia
continental circus 
dominator 
stryx
driller 
millipede 
zynaps
pacland
theme park mystery 
plotting 
quartz 
fusion 
overlander 
bubble bobble 
jim power 
lotus 1 
starwars 
gemX 
bloodmoney




Now, most of ATARI ST Games, and Classical TOS or GEM applications 
can run on your Dreamcast , bringing all the original Atari ST Look & Fell. 


In this release candidate 6 to Final were accurated and improved latest 
coding features in KOS, SDL and C in order to get the best emulation as 
possible, maintaining a high grade of compatibility, even in both color modes. 


At this moment, Monochrome video mode is not available yet



// BCC
OP_0x6201:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_notZ && (!(CPU->flag_C & 0x100)))
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6301:
{
	u32 adr, res;
	u32 src, dst;

	if ((!CPU->flag_notZ) || (CPU->flag_C & 0x100))
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6401:
{
	u32 adr, res;
	u32 src, dst;

	if (!(CPU->flag_C & 0x100))
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6501:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_C & 0x100)
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6601:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_notZ)
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6701:
{
	u32 adr, res;
	u32 src, dst;

	if (!CPU->flag_notZ)
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6801:
{
	u32 adr, res;
	u32 src, dst;

	if (!(CPU->flag_V & 0x80))
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6901:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_V & 0x80)
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6A01:
{
	u32 adr, res;
	u32 src, dst;

	if (!(CPU->flag_N & 0x80))
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6B01:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_N & 0x80)
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6C01:
{
	u32 adr, res;
	u32 src, dst;

	if (!((CPU->flag_N ^ CPU->flag_V) & 0x80))
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6D01:
{
	u32 adr, res;
	u32 src, dst;

	if ((CPU->flag_N ^ CPU->flag_V) & 0x80)
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6E01:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_notZ && (!((CPU->flag_N ^ CPU->flag_V) & 0x80)))
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC
OP_0x6F01:
{
	u32 adr, res;
	u32 src, dst;

	if ((!CPU->flag_notZ) || ((CPU->flag_N ^ CPU->flag_V) & 0x80))
	{
		PC += (s32)(s8)Opcode;
	CCnt -= 2;
	}
}
RET(8)

// BCC16
OP_0x6200:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_notZ && (!(CPU->flag_C & 0x100)))
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6300:
{
	u32 adr, res;
	u32 src, dst;

	if ((!CPU->flag_notZ) || (CPU->flag_C & 0x100))
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6400:
{
	u32 adr, res;
	u32 src, dst;

	if (!(CPU->flag_C & 0x100))
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6500:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_C & 0x100)
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6600:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_notZ)
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6700:
{
	u32 adr, res;
	u32 src, dst;

	if (!CPU->flag_notZ)
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6800:
{
	u32 adr, res;
	u32 src, dst;

	if (!(CPU->flag_V & 0x80))
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6900:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_V & 0x80)
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6A00:
{
	u32 adr, res;
	u32 src, dst;

	if (!(CPU->flag_N & 0x80))
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6B00:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_N & 0x80)
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6C00:
{
	u32 adr, res;
	u32 src, dst;

	if (!((CPU->flag_N ^ CPU->flag_V) & 0x80))
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6D00:
{
	u32 adr, res;
	u32 src, dst;

	if ((CPU->flag_N ^ CPU->flag_V) & 0x80)
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6E00:
{
	u32 adr, res;
	u32 src, dst;

	if (CPU->flag_notZ && (!((CPU->flag_N ^ CPU->flag_V) & 0x80)))
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BCC16
OP_0x6F00:
{
	u32 adr, res;
	u32 src, dst;

	if ((!CPU->flag_notZ) || ((CPU->flag_N ^ CPU->flag_V) & 0x80))
	{
		PC += (s32)(s16)FETCH_WORD;
		PC -= CPU->BasePC;
		SET_PC(PC);
	RET(10)
	}
	PC += 2;
}
RET(12)

// BRA
OP_0x6001:
{
	u32 adr, res;
	u32 src, dst;

	PC += (s32)(s8)Opcode;
}
RET(10)

// BRA16
OP_0x6000:
{
	u32 adr, res;
	u32 src, dst;

	PC += (s32)(s16)FETCH_WORD;
	PC -= CPU->BasePC;
	SET_PC(PC);
}
RET(10)

// BSR
OP_0x6101:
{
	u32 adr, res;
	u32 src, dst;

	PRE_IO
	PUSH_32_F(PC - CPU->BasePC)
	PC += (s32)(s8)Opcode;
	POST_IO
}
RET(18)

// BSR16
OP_0x6100:
{
	u32 adr, res;
	u32 src, dst;

	res = (s32)(s16)FETCH_WORD;
	PC -= CPU->BasePC;
	PRE_IO
	PUSH_32_F(PC + 2)
	PC += res;
	SET_PC(PC);
	POST_IO
}
RET(18)

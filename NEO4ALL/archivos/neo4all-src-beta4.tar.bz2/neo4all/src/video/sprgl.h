
#define COORD_A_U 0.0
#define COORD_A_V 0.0

#define COORD_B_U 1.0
#define COORD_B_V 0.0

#define COORD_C_U 1.0
#define COORD_C_V 1.0

#define COORD_D_U 0.0
#define COORD_D_V 1.0

#define GL_SCALE_X 1.052631578947368f
#define GL_MOVE_X 8.0f
#define GL_SCALE_Y 1.071428571428571f

#ifndef DREAMCAST
#define SCALE_X GL_SCALE_X
#define MOVE_X GL_MOVE_X
#define SCALE_Y GL_SCALE_Y
#define MOVE_Y GL_MOVE_X
#else
//#define SCALE_X (2.14f/(640.0f/VIDEO_GL_WIDTH))
//#define SCALE_X (2.1399825021872266f/(640.0f/VIDEO_GL_WIDTH))
//#define SCALE_X (2.133333333333333f/(640.0f/VIDEO_GL_WIDTH))
/*
#define SCALE_X (2.105263157894737f/(640.0f/VIDEO_GL_WIDTH))
#define MOVE_X (16.0f/(640.0f/VIDEO_GL_WIDTH))
#define SCALE_Y SCALE_X
#define MOVE_Y (16.0f/(640.0f/VIDEO_GL_WIDTH))
//#define SCALE_Y (2.142857142857143f/(640.0f/VIDEO_GL_WIDTH))
//*/

#define SCALE_X (2.0f/(640.0f/VIDEO_GL_WIDTH))
#define MOVE_X (16.0f/(640.0f/VIDEO_GL_WIDTH))
#define SCALE_Y SCALE_X
#define MOVE_Y (16.0f/(640.0f/VIDEO_GL_WIDTH))

#endif

/*
#define VERTEX_1_X ((((float)sx)*SCALE_X)-MOVE_X)
#define VERTEX_1_Y (((float)sy)*SCALE_Y)
#define VERTEX_2_X ((((float)sx+(float)zx)*SCALE_X)-MOVE_X)
#define VERTEX_2_Y (((float)sy)*SCALE_Y)
#define VERTEX_3_X ((((float)sx+(float)zx)*SCALE_X)-MOVE_X)
#define VERTEX_3_Y (((float)sy+(float)zy)*SCALE_Y)
#define VERTEX_4_X ((((float)sx)*SCALE_X)-MOVE_X)
#define VERTEX_4_Y (((float)sy+(float)zy)*SCALE_Y)
*/

#define VERTEX_1_X ((((float)sx)*SCALE_X))
#define VERTEX_1_Y ((((float)sy)*SCALE_Y)+MOVE_Y)
#define VERTEX_2_X ((((float)sx+(float)zx)*SCALE_X))
#define VERTEX_2_Y ((((float)sy)*SCALE_Y)+MOVE_Y)
#define VERTEX_3_X ((((float)sx+(float)zx)*SCALE_X))
#define VERTEX_3_Y ((((float)sy+(float)zy)*SCALE_Y)+MOVE_Y)
#define VERTEX_4_X ((((float)sx)*SCALE_X))
#define VERTEX_4_Y ((((float)sy+(float)zy)*SCALE_Y)+MOVE_Y)

#define GL_VERTICE(U,V,X,Y) \
	    glTexCoord2f(U,V); \
    	    glVertex3f(X,Y,tile_z);

#define GL_VERTICE_EOL(U,V,X,Y) GL_VERTICE(U,V,X,Y)

#define GL_VERTICE_FLIP_XY \
   GL_VERTICE(COORD_C_U,COORD_C_V,VERTEX_1_X,VERTEX_1_Y) \
   GL_VERTICE(COORD_D_U,COORD_C_V,VERTEX_2_X,VERTEX_2_Y) \
   GL_VERTICE(COORD_A_U,COORD_A_V,VERTEX_3_X,VERTEX_3_Y) \
   GL_VERTICE_EOL(COORD_B_U,COORD_B_V,VERTEX_4_X,VERTEX_4_Y)

#define GL_VERTICE_FLIP_X \
   GL_VERTICE(COORD_B_U,COORD_B_V,VERTEX_1_X,VERTEX_1_Y) \
   GL_VERTICE(COORD_A_U,COORD_A_U,VERTEX_2_X,VERTEX_2_Y) \
   GL_VERTICE(COORD_D_U,COORD_D_V,VERTEX_3_X,VERTEX_3_Y) \
   GL_VERTICE_EOL(COORD_C_U,COORD_C_V,VERTEX_4_X,VERTEX_4_Y)

#define GL_VERTICE_FLIP_Y \
   GL_VERTICE(COORD_D_U,COORD_D_V,VERTEX_1_X,VERTEX_1_Y) \
   GL_VERTICE(COORD_C_U,COORD_C_V,VERTEX_2_X,VERTEX_2_Y) \
   GL_VERTICE(COORD_B_U,COORD_B_V,VERTEX_3_X,VERTEX_3_Y) \
   GL_VERTICE_EOL(COORD_A_U,COORD_A_V,VERTEX_4_X,VERTEX_4_Y) 

#define GL_VERTICE_FLIP_NONE \
   GL_VERTICE(COORD_A_U,COORD_A_V,VERTEX_1_X,VERTEX_1_Y) \
   GL_VERTICE(COORD_B_U,COORD_B_V,VERTEX_2_X,VERTEX_2_Y) \
   GL_VERTICE(COORD_C_U,COORD_C_V,VERTEX_3_X,VERTEX_3_Y) \
   GL_VERTICE_EOL(COORD_D_U,COORD_D_V,VERTEX_4_X,VERTEX_4_Y)



#ifndef DREAMCAST
#define VERTICE_INIT GL_VERTICE_INIT
#define VERTICE_INIT_EOL GL_VERTICE_INIT_EOL
#define VERTICE_FLIP_XY GL_VERTICE_FLIP_XY 
#define VERTICE_FLIP_X GL_VERTICE_FLIP_X 
#define VERTICE_FLIP_Y GL_VERTICE_FLIP_Y 
#define VERTICE_FLIP_NONE GL_VERTICE_FLIP_NONE 
#else


#define VERTICE_INIT \
	{ \
		pvr_vertex_t  *vert=pvr_dr_target(dr_state); \
		vert->argb = 0xffffffff; \
		vert->oargb = 0xff000000; \
		vert->flags = PVR_CMD_VERTEX;

#define VERTICE_INIT_EOL \
	{ \
		pvr_vertex_t  *vert=pvr_dr_target(dr_state); \
		vert->argb = 0xffffffff; \
		vert->oargb = 0xff000000; \
		vert->flags = PVR_CMD_VERTEX_EOL; 

#define VERTICE_BODY(X,Y,U,V) \
		vert->x =X; \
		vert->y =Y; \
		vert->z =(float)tile_z; \
		vert->u =U; \
		vert->v =V; \
		pvr_dr_commit(vert); \
	}


#define VERTICE(U,V,X,Y) \
		VERTICE_INIT \
		VERTICE_BODY((float)X,(float)Y,(float)U,(float)V)

#define VERTICE_EOL(U,V,X,Y) \
		VERTICE_INIT_EOL \
		VERTICE_BODY((float)X,(float)Y,(float)U,(float)V)

#define VERTICE_FLIP_XY \
   VERTICE(COORD_B_U,COORD_B_V,VERTEX_4_X,VERTEX_4_Y) \
   VERTICE(COORD_A_U,COORD_A_V,VERTEX_3_X,VERTEX_3_Y) \
   VERTICE(COORD_C_U,COORD_C_V,VERTEX_1_X,VERTEX_1_Y) \
   VERTICE_EOL(COORD_D_U,COORD_D_V,VERTEX_2_X,VERTEX_2_Y)

#define VERTICE_FLIP_X \
   VERTICE(COORD_B_U,COORD_B_V,VERTEX_1_X,VERTEX_1_Y) \
   VERTICE(COORD_A_U,COORD_A_V,VERTEX_2_X,VERTEX_2_Y) \
   VERTICE(COORD_C_U,COORD_C_V,VERTEX_4_X,VERTEX_4_Y) \
   VERTICE_EOL(COORD_D_U,COORD_D_V,VERTEX_3_X,VERTEX_3_Y)

#define VERTICE_FLIP_Y \
   VERTICE(COORD_A_U,COORD_A_V,VERTEX_4_X,VERTEX_4_Y) \
   VERTICE(COORD_B_U,COORD_B_V,VERTEX_3_X,VERTEX_3_Y) \
   VERTICE(COORD_D_U,COORD_D_V,VERTEX_1_X,VERTEX_1_Y) \
   VERTICE_EOL(COORD_C_U,COORD_C_V,VERTEX_2_X,VERTEX_2_Y)

#define VERTICE_FLIP_NONE \
   VERTICE(COORD_A_U,COORD_A_V,VERTEX_1_X,VERTEX_1_Y) \
   VERTICE(COORD_B_U,COORD_B_V,VERTEX_2_X,VERTEX_2_Y) \
   VERTICE(COORD_D_U,COORD_D_V,VERTEX_4_X,VERTEX_4_Y) \
   VERTICE_EOL(COORD_C_U,COORD_C_V,VERTEX_3_X,VERTEX_3_Y)

#endif

extern void *neo4all_texture_buffer;


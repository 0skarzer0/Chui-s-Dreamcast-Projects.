 /*
  * NO Call Amiga Exec
  */

